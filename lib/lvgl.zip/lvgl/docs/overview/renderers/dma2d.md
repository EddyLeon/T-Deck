```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/overview/renderers/dma2d.md
```
# DMA2D GPU

TODO

