```eval_rst
.. include:: /header.rst
:github_url: |github_link_base|/get-started/index.md
```
# Platforms

```eval_rst

.. toctree::
   :maxdepth: 2

   pc-simulator
   nxp
   stm32
   espressif
   arduino
   tasmota-berry
   cmake
```

